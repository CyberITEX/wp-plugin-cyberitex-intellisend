/**
 * IntelliSend Settings Page JavaScript
 * 
 * Handles enhanced functionality for the settings page.
 */

(function($) {
    'use strict';

    // Document ready
    $(function() {
        /**
         * Password visibility toggle
         */
        function initPasswordToggle() {
            const eyeOpenSvg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
            const eyeClosedSvg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>';
            
            // Create toggle button and add it to the password field container
            const $apiKeyField = $('#api-key');
            $apiKeyField.wrap('<div class="password-field-container"></div>');
            
            const $toggleButton = $('<button type="button" class="password-toggle" aria-label="Toggle password visibility">' + eyeClosedSvg + '</button>');
            $apiKeyField.after($toggleButton);
            
            // Set initial type to password
            $apiKeyField.attr('type', 'password');
            
            // Handle toggle click
            $toggleButton.on('click', function(e) {
                e.preventDefault();
                
                const isVisible = $apiKeyField.attr('type') === 'text';
                
                // Toggle password visibility
                $apiKeyField.attr('type', isVisible ? 'password' : 'text');
                
                // Update icon
                $(this).html(isVisible ? eyeClosedSvg : eyeOpenSvg);
            });
        }
        
        /**
         * Logs retention dropdown
         */
        function initLogsRetentionDropdown() {
            // Define retention options
            const retentionOptions = [
                { label: '1 Week', days: 7 },
                { label: '1 Month', days: 30 },
                { label: '3 Months', days: 90 },
                { label: '6 Months', days: 180 },
                { label: '1 Year', days: 365 }
            ];
            
            // Get the current value
            const $originalInput = $('#logs-retention-days');
            const currentDays = parseInt($originalInput.val(), 10) || 30;
            
            // Create select element
            const $select = $('<select id="logs-retention-select" class="logs-retention-select"></select>');
            
            // Add options to select
            $.each(retentionOptions, function(index, option) {
                const $option = $('<option></option>')
                    .val(option.days)
                    .text(option.label);
                
                // Set selected option based on current value
                if (currentDays === option.days) {
                    $option.prop('selected', true);
                } else if (index === 0 && !retentionOptions.some(opt => opt.days === currentDays)) {
                    // If current value doesn't match any option, select first option
                    $option.prop('selected', true);
                    $originalInput.val(option.days);
                }
                
                $select.append($option);
            });
            
            // Add custom option if current value doesn't match any predefined option
            if (!retentionOptions.some(opt => opt.days === currentDays)) {
                const $customOption = $('<option></option>')
                    .val(currentDays)
                    .text(currentDays + ' Days (Custom)')
                    .prop('selected', true);
                
                $select.append($customOption);
            }
            
            // Replace the original input with the select
            $originalInput.after($select);
            
            // Update hidden input when select changes
            $select.on('change', function() {
                $originalInput.val($(this).val());
            });
        }
        
        /**
         * Form submission handling
         */
        function initFormSubmission() {
            $('#intellisend-settings-form').on('submit', function(e) {
                e.preventDefault();
                
                const $form = $(this);
                const $submitButton = $form.find('button[type="submit"]');
                
                // Add loading state
                $submitButton.addClass('is-loading').prop('disabled', true);
                $submitButton.append('<span class="loading-spinner"></span>');
                
                // Disable all other buttons
                $form.find('button').not($submitButton).prop('disabled', true);
                
                // Get form data
                const formData = $form.serialize();
                
                // Send AJAX request
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'intellisend_save_settings',
                        formData: formData,
                        nonce: $('#intellisend_settings_nonce').val()
                    },
                    success: function(response) {
                        // Remove any existing notices
                        $('.intellisend-notice').remove();
                        
                        if (response.success) {
                            // Show success message
                            const successNotice = `
                                <div class="intellisend-notice success">
                                    <span class="intellisend-notice-icon dashicons dashicons-yes-alt"></span>
                                    <div class="intellisend-notice-content">Settings saved successfully.</div>
                                </div>
                            `;
                            $form.before(successNotice);
                        } else {
                            // Show error message
                            const errorNotice = `
                                <div class="intellisend-notice error">
                                    <span class="intellisend-notice-icon dashicons dashicons-warning"></span>
                                    <div class="intellisend-notice-content">${response.data || 'An error occurred while saving settings.'}</div>
                                </div>
                            `;
                            $form.before(errorNotice);
                        }
                    },
                    error: function() {
                        // Show error message for network/server errors
                        $('.intellisend-notice').remove();
                        const errorNotice = `
                            <div class="intellisend-notice error">
                                <span class="intellisend-notice-icon dashicons dashicons-warning"></span>
                                <div class="intellisend-notice-content">A network error occurred. Please try again.</div>
                            </div>
                        `;
                        $form.before(errorNotice);
                    },
                    complete: function() {
                        // Remove loading state
                        $submitButton.removeClass('is-loading').prop('disabled', false);
                        $submitButton.find('.loading-spinner').remove();
                        
                        // Re-enable all other buttons
                        $form.find('button').prop('disabled', false);
                        
                        // Scroll to top of form to show notification
                        $('html, body').animate({
                            scrollTop: $form.parent().offset().top - 50
                        }, 300);
                    }
                });
            });
        }
        
        /**
         * Spam detection test
         */
        function initSpamDetectionTest() {
            $('#test-spam-detection').on('click', function() {
                const $button = $(this);
                const apiKey = $('#api-key').val();
                const endpoint = $('#anti-spam-endpoint').val();
                const testMessage = $('#spam-test-message').val();
                
                // Validation
                if (!apiKey) {
                    alert('Please enter an API key first.');
                    $('#api-key').focus();
                    return;
                }
                
                if (!endpoint) {
                    alert('Please enter an API endpoint first.');
                    $('#anti-spam-endpoint').focus();
                    return;
                }
                
                if (!testMessage) {
                    alert('Please enter a test message first.');
                    $('#spam-test-message').focus();
                    return;
                }
                
                // Add loading state
                $button.addClass('is-loading').prop('disabled', true);
                $button.append('<span class="loading-spinner"></span>');
                
                // Send AJAX request
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'intellisend_test_spam_detection',
                        apiKey: apiKey,
                        endpoint: endpoint,
                        message: testMessage,
                        nonce: $('#intellisend_settings_nonce').val()
                    },
                    success: function(response) {
                        if (response.success) {
                            if (response.data.is_spam) {
                                alert('Message detected as SPAM with score: ' + response.data.score);
                            } else {
                                alert('Message is NOT spam. Score: ' + response.data.score);
                            }
                        } else {
                            alert('Error: ' + (response.data || 'An unknown error occurred.'));
                        }
                    },
                    error: function() {
                        alert('A network error occurred. Please try again.');
                    },
                    complete: function() {
                        // Remove loading state
                        $button.removeClass('is-loading').prop('disabled', false);
                        $button.find('.loading-spinner').remove();
                    }
                });
            });
        }
        
        /**
         * Send test email
         */
        function initSendTestEmail() {
            $('#send-test-email').on('click', function() {
                const $button = $(this);
                const testRecipient = $('#test-recipient').val();
                const defaultProvider = $('#default-provider').val();
                
                // Validation
                if (!testRecipient) {
                    alert('Please enter a test recipient email address first.');
                    $('#test-recipient').focus();
                    return;
                }
                
                // Email validation
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(testRecipient)) {
                    alert('Please enter a valid email address.');
                    $('#test-recipient').focus();
                    return;
                }
                
                // Add loading state
                $button.addClass('is-loading').prop('disabled', true);
                $button.append('<span class="loading-spinner"></span>');
                
                // Send AJAX request
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'intellisend_ajax_handler',
                        sub_action: 'test_email_sent',
                        test_email: testRecipient,
                        provider_id: defaultProvider,
                        nonce: $('#intellisend_settings_nonce').val()
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('Test email sent successfully to ' + testRecipient);
                        } else {
                            alert('Error: ' + (response.data || 'Failed to send test email.'));
                        }
                    },
                    error: function() {
                        alert('A network error occurred. Please try again.');
                    },
                    complete: function() {
                        // Remove loading state
                        $button.removeClass('is-loading').prop('disabled', false);
                        $button.find('.loading-spinner').remove();
                    }
                });
            });
        }
        
        // Initialize all features
        initPasswordToggle();
        initLogsRetentionDropdown();
        initFormSubmission();
        initSpamDetectionTest();
        initSendTestEmail();
    });
})(jQuery);
