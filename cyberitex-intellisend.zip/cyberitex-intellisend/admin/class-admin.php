<?php

/**
 * IntelliSend Admin
 *
 * @package IntelliSend
 * @subpackage Admin
 */

// If this file is called directly, abort.
if (! defined('WPINC')) {
    die;
}

// Include admin page files - only when in admin area to prevent activation issues
if (is_admin()) {
    require_once plugin_dir_path(__FILE__) . 'class-ajax.php';
}

/**
 * IntelliSend Admin Class
 */
class IntelliSend_Admin
{

    /**
     * Initialize the admin class
     */
    public static function init()
    {
        // Register hooks
        add_action('admin_menu', array(__CLASS__, 'register_admin_menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_admin_scripts'));
        add_action('admin_init', array(__CLASS__, 'check_providers_redirect'));

        // Add settings link to plugins page
        add_filter(
            'plugin_action_links_' . plugin_basename(INTELLISEND_PLUGIN_DIR . 'cyberitex-intellisend.php'),
            array(__CLASS__, 'add_settings_link')
        );

        // Initialize AJAX handler - only when in admin area
        if (is_admin() && class_exists('IntelliSend_Ajax')) {
            IntelliSend_Ajax::init();
        }
    }
    
    /**
     * Check if providers exist and redirect if needed
     */
    public static function check_providers_redirect()
    {
        // Only run on the main settings page
        if (!isset($_GET['page']) || $_GET['page'] !== 'intellisend') {
            return;
        }
        
        // Check if any providers are configured
        if (class_exists('IntelliSend_Database')) {
            $providers = IntelliSend_Database::get_providers(array('configured' => 1));
            
            // If no providers are configured, redirect to providers page
            if (empty($providers)) {
                wp_redirect(admin_url('admin.php?page=intellisend-providers'));
                exit;
            }
        }
    }

    /**
     * Register the admin menu page.
     *
     * @since    1.0.0
     */
    public static function register_admin_menu()
    {
        // Main menu
        add_menu_page(
            'IntelliSend',
            'IntelliSend',
            'manage_options',
            'intellisend',
            array(__CLASS__, 'render_settings_page'),
            'dashicons-email',
            30
        );

        // Submenu items - first item with same slug as parent to replace default submenu
        add_submenu_page(
            'intellisend',
            'Settings',
            'Settings',
            'manage_options',
            'intellisend',
            array(__CLASS__, 'render_settings_page')
        );

        add_submenu_page(
            'intellisend',
            'SMTP Providers',
            'SMTP Providers',
            'manage_options',
            'intellisend-providers',
            array(__CLASS__, 'render_providers_page')
        );

        add_submenu_page(
            'intellisend',
            'Email Routing',
            'Email Routing',
            'manage_options',
            'intellisend-routing',
            array(__CLASS__, 'render_routing_page')
        );

        add_submenu_page(
            'intellisend',
            'Email Reports',
            'Reports',
            'manage_options',
            'intellisend-reports',
            array(__CLASS__, 'render_reports_page')
        );
    }

    /**
     * Render the admin pages by including the appropriate view files
     */
    public static function render_settings_page()
    {
        require_once INTELLISEND_PLUGIN_DIR . 'admin/views/settings-page.php';
        if (function_exists('intellisend_render_settings_page_content')) {
            intellisend_render_settings_page_content();
        }
    }

    public static function render_providers_page()
    {
        require_once INTELLISEND_PLUGIN_DIR . 'admin/views/providers-page.php';
        if (function_exists('intellisend_render_providers_page_content')) {
            intellisend_render_providers_page_content();
        }
    }

    public static function render_routing_page()
    {
        require_once INTELLISEND_PLUGIN_DIR . 'admin/views/routing-page.php';
        if (function_exists('intellisend_render_routing_page_content')) {
            intellisend_render_routing_page_content();
        }
    }

    public static function render_reports_page()
    {
        // admin.php?page=intellisend-reports&report=<id> shows one report on its
        // own page. WordPress resolves ?page= against a registered menu slug, so
        // the id travels as a separate argument rather than as a path segment.
        $report_id = isset($_GET['report']) && is_string($_GET['report']) && ctype_digit($_GET['report'])
            ? (int) $_GET['report']
            : 0;

        if ($report_id > 0) {
            require_once INTELLISEND_PLUGIN_DIR . 'admin/views/report-single.php';
            if (function_exists('intellisend_render_single_report_content')) {
                intellisend_render_single_report_content($report_id);
            }
            return;
        }

        require_once INTELLISEND_PLUGIN_DIR . 'admin/views/reports-page.php';
        if (function_exists('intellisend_render_reports_page_content')) {
            intellisend_render_reports_page_content();
        }
    }

    /**
     * Register the JavaScript and CSS for the admin area.
     *
     * @param string $hook The current admin page.
     */
    public static function enqueue_admin_scripts($hook)
    {
        // Only load on plugin pages
        if (strpos($hook, 'intellisend') !== false) {
            // Always load the main admin CSS and JS
            wp_enqueue_style(
                'intellisend-admin-style',
                INTELLISEND_PLUGIN_URL . 'admin/css/intellisend-admin.css',
                array(),
                INTELLISEND_VERSION,
                'all'
            );

            wp_enqueue_script(
                'intellisend-admin-script',
                INTELLISEND_PLUGIN_URL . 'admin/js/intellisend-admin.js',
                array('jquery'),
                INTELLISEND_VERSION,
                false
            );

            // Localize script with AJAX data
            wp_localize_script(
                'intellisend-admin-script',
                'intellisendData',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('intellisend_nonce'),
                    'strings' => array(
                        'confirm_delete' => __('Are you sure you want to delete this item?', 'intellisend')
                    )
                )
            );

            // Add WordPress admin styles
            wp_enqueue_style('wp-admin');
            wp_enqueue_style('dashicons');

            // Load page-specific files
            if ($hook === 'toplevel_page_intellisend') {
                // Settings page
                wp_enqueue_style(
                    'intellisend-settings-style',
                    INTELLISEND_PLUGIN_URL . 'admin/css/settings-page.css',
                    array(),
                    INTELLISEND_VERSION,
                    'all'
                );

                wp_enqueue_script(
                    'intellisend-toast-script',
                    INTELLISEND_PLUGIN_URL . 'admin/js/intellisend-toast.js',
                    array('jquery'),
                    INTELLISEND_VERSION,
                    false
                );

                wp_enqueue_script(
                    'intellisend-settings-script',
                    INTELLISEND_PLUGIN_URL . 'admin/js/settings-page.js',
                    array('jquery', 'intellisend-toast-script'),
                    INTELLISEND_VERSION,
                    false
                );
            } elseif ($hook === 'intellisend_page_intellisend-providers') {
                wp_enqueue_style(
                    'intellisend-providers-style',
                    INTELLISEND_PLUGIN_URL . 'admin/css/providers-page.css',
                    array(),
                    INTELLISEND_VERSION,
                    'all'
                );

                wp_enqueue_script(
                    'intellisend-providers-script',
                    INTELLISEND_PLUGIN_URL . 'admin/js/providers-page.js',
                    array('jquery'),
                    INTELLISEND_VERSION,
                    false
                );

                // Describe each API transport so the page can render its own
                // key placeholder, region choices and hints.
                wp_localize_script(
                    'intellisend-providers-script',
                    'intellisendProviders',
                    array(
                        'transports' => class_exists('IntelliSend_Api_Transport')
                            ? IntelliSend_Api_Transport::describe_all()
                            : array(),
                    )
                );
            } elseif ($hook === 'intellisend_page_intellisend-routing') {
                wp_enqueue_style(
                    'intellisend-routes-style',
                    INTELLISEND_PLUGIN_URL . 'admin/css/routing-page.css',
                    array(),
                    INTELLISEND_VERSION,
                    'all'
                );

                wp_enqueue_script(
                    'intellisend-routing-js',
                    INTELLISEND_PLUGIN_URL . 'admin/js/routing-page.js',
                    array('jquery'),
                    INTELLISEND_VERSION,
                    false
                );
                
                // Localize script with routing-specific data
                wp_localize_script(
                    'intellisend-routing-js',
                    'intellisendData',
                    array(
                        'ajax_url' => admin_url('admin-ajax.php'),
                        'nonce' => wp_create_nonce('intellisend_routing_nonce'),
                        'strings' => array(
                            'unconfiguredProvider' => __('The provider "%s" is not configured. Please select a configured provider or configure this provider in the SMTP Providers section.', 'intellisend'),
                            'confirmDelete' => __('Are you sure you want to delete this routing rule? This action cannot be undone.', 'intellisend'),
                            'noConfiguredProviders' => __('No configured SMTP providers found. Please configure at least one provider before adding routing rules.', 'intellisend')
                        )
                    )
                );
            } elseif ($hook === 'intellisend_page_intellisend-reports') {
                wp_enqueue_style(
                    'intellisend-reports-style',
                    INTELLISEND_PLUGIN_URL . 'admin/css/reports-page.css',
                    array(),
                    INTELLISEND_VERSION,
                    'all'
                );

                wp_enqueue_script(
                    'intellisend-reports-script',
                    INTELLISEND_PLUGIN_URL . 'admin/js/reports-page.js',
                    array('jquery'),
                    INTELLISEND_VERSION,
                    false
                );
                
                // Localize script with reports-specific data
                wp_localize_script(
                    'intellisend-reports-script',
                    'intellisendData',
                    array(
                        'ajax_url' => admin_url('admin-ajax.php'),
                        'nonce' => wp_create_nonce('intellisend_ajax_nonce'),
                        'strings' => array(
                            'confirmDelete' => __('Are you sure you want to delete the selected reports? This action cannot be undone.', 'intellisend'),
                            'confirmDeleteAll' => __('Are you sure you want to delete ALL reports? This action cannot be undone.', 'intellisend'),
                            'noReportsSelected' => __('Please select at least one report to delete.', 'intellisend')
                        )
                    )
                );
            }

            // Load theme tokens after page styles so colours are consistent
            // across every IntelliSend screen.
            wp_enqueue_style(
                'intellisend-theme-style',
                INTELLISEND_PLUGIN_URL . 'admin/css/theme.css',
                array('intellisend-admin-style'),
                INTELLISEND_VERSION,
                'all'
            );

            // IntelliSend renders light on every screen by default, whatever the
            // operating system or WordPress admin colour scheme says. Sites that
            // want the dark scheme back opt in:
            //
            //     add_filter( 'intellisend_enable_dark_mode', '__return_true' );
            //
            // The dark sheet still honours prefers-color-scheme, so opting in
            // means "follow the operating system", not "always dark".
            if (apply_filters('intellisend_enable_dark_mode', false)) {
                wp_enqueue_style(
                    'intellisend-theme-dark-style',
                    INTELLISEND_PLUGIN_URL . 'admin/css/theme-dark.css',
                    array('intellisend-theme-style'),
                    INTELLISEND_VERSION,
                    'all'
                );
            }
        }
    }

    /**
     * Add settings link to the plugins page
     * 
     * @param array $links Plugin action links
     * @return array Modified plugin action links
     */
    public static function add_settings_link($links)
    {
        $settings_link = '<a href="admin.php?page=intellisend">Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}

// Initialize the admin class - only when in admin area
if (is_admin()) {
    add_action('plugins_loaded', array('IntelliSend_Admin', 'init'));
}
